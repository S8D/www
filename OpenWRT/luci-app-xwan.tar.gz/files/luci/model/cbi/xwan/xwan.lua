-- Copyright 2019 X-WRT <dev@x-wrt.com>

m = Map("xwan", translate("xWan"))

s = m:section(TypedSection, "xwan", translate("Cài đặt xWan"))
s.addremove = false
s.anonymous = true

e = s:option(Flag, "enabled", translate("Bật xWan"), translate("Nhiều wan trên cổng"))
e.default = e.disabled
e.rmempty = false

e = s:option(Value, "number", translate("Số xWan"))
e.datatype = "and(uinteger,min(1),max(60))"
e.rmempty  = false

e = s:option(Flag, "balanced", translate("Cài đặt tự động cân bằng"))
e.default = e.disabled
e.rmempty = false

return m